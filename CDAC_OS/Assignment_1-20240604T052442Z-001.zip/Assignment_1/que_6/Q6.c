#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>
#include<stdlib.h>
int main()
{
	int ret;
	ret=fork();

	if (ret<0)
	{
		perror("Error");
		exit(0);
	}
	if(ret==0)
	{
		printf("In child process. pid: %d , ppid: %d\n",getpid(),getppid());
		execl("/home/desd/embedded_os/Assignment_1/./hello"," ",NULL);
		exit(0);
		}
	else if(ret > 0)
	{
		   printf("In parent process. pid: %d\n",getpid());
		   exit(0);
	}
	return 0;
}


