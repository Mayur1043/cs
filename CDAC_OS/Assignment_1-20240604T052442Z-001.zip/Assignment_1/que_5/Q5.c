#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>
#include<stdlib.h>
int main()
{
	int child;
	child=fork();

	if(child==0)
	{
		printf("In child process. pid: %d , ppid: %d\n",getpid(),getppid());
		execl("/usr/bin/evince","evince","/home/desd/i3g4250d.pdf",NULL);
		exit(0);
	}
	else if(child > 0)
	{
		   printf("In parent process. pid: %d\n",getpid());
		   exit(0);
	}
	return 0;
}


