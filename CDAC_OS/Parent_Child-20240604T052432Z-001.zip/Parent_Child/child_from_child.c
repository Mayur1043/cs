#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>

int main()
{
	int c1;
	c1=fork();
	if(c1==0)
	{
		int c2;
		c2=fork();
		if(c2==0)
		{
			printf("I am in child process 2. pid: %d ppid: %d\n",getpid(),getppid());
		}
		else if(c2>0)
		{
			printf("I am in Child process 1. pid: %d ppid: %d\n",getpid(),getppid());
		}
	}
	else if(c1>0)
	{
		printf("I am in Parent process pid: %d\n",getpid());
	}
	else{
		printf("No child is created");
	}
	return 0;
}
