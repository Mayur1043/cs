#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>

int main()
{
	int c1, c2;
	c1=fork();

if (c1 == 0) {
    printf("I am in Child 1 with pid: %d ppdid: %d\n",getpid(), getppid());
} 
else {
    c2 = fork();
    if (c2 == 0) {
          printf("I am in Child 2 with pid: %d ppdid: %d\n",getpid(), getppid());
    } 
    else {
          printf("I am in Parent process with pid: %d\n",getpid());
    }
}

	return 0;
}
