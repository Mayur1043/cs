#include<stdio.h>
#include<sys/types.h>
#include<fcntl.h>
#include<sys/stat.h>
#include<unistd.h>
#include<stdlib.h>
#include<string.h>
#include<stdio_ext.h>

int main(int argc, char *argv[])
{
	char buf[512],wr_buf[512];	
   	int ret,ret1,status;
   	int fd1,fd2,fd3,pfd[2];
	int c1, c2;
	
	
	ret = pipe(pfd);
	
	 if(ret<0) 
	 {
	 	perror("error in pipe"); 
	 	exit(2); 
	 }
	
	c1=fork();

if (c1 == 0) {
    	printf("I am in Child 1 with pid: %d ppdid: %d\n",getpid(), getppid());
    	
        close(pfd[0]);   //closing the read handle     	
      	printf("\nEnter some value here: ");
	__fpurge(stdin);
	fgets(wr_buf,512,stdin);
     	write(pfd[1],wr_buf,strlen(wr_buf)+1); //this is right 
      	close(pfd[1]);
    /*	close(pfd[1]); //closing the write handle
    	
    	while( (ret1 = read(pfd[0],wr_buf,512)) >0)
	   {
		//printf("%s\n", buf);		 
                write(STDOUT_FILENO,wr_buf,ret1);
		 //fflush(stdout);
	   }  
	   if(ret1<0){ 
	 
	   } 
	   close(pfd[0]);*/
   }

else {
    c2 = fork();
    if (c2 == 0) {
      	printf("I am in Child 2 with pid: %d ppdid: %d\n",getpid(), getppid());
       /* close(pfd[0]);   //closing the read handle     	
      	printf("Enter some value here: ");
	scanf("%[^\n]s",wr_buf);
     	write(pfd[1],wr_buf,strlen(wr_buf)+1); //this is right 
      	close(pfd[1]);

*/
    	close(pfd[1]); //closing the write handle
    	
    	while( (ret1 = read(pfd[0],wr_buf,512)) >0)
	   {
		//printf("%s\n", buf);		 
                write(STDOUT_FILENO,wr_buf,ret1);
		 //fflush(stdout);
	   }  
	   if(ret1<0){ 
	 
	   } 
    	   close(pfd[0]);
    }
    else {
          printf("I am in Parent process with pid: %d\n",getpid());
    }
}

	return 0;
}
