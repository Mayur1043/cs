#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/msg.h>

#define KEY1 1552

struct message {
    long mtype;
    char mtext[100];
};

int main() {
    int msgqid, ret1,ret2;
    struct message msg;
    struct message msg2;

    // Create or get the message queue
    msgqid = msgget(KEY1, 0666 | IPC_CREAT);
    if (msgqid <0 ) {
        perror("msgget");
        exit(1);
    }

    // Prepare the message to send
    msg.mtype = 1;
    strcpy(msg.mtext, "Hello, message queue");
    msg2.mtype=2;
    strcpy(msg2.mtext,"Thank you");

    // Send the message
    ret1 = msgsnd(msgqid, &msg, sizeof(struct message), 0); 
    ret2 = msgsnd(msgqid, &msg2, sizeof(struct message),0);
    if (ret1 < 0)
    {
        perror("msgsnd");
        exit(1);
    }
    if(ret2 < 0)
    {
	    perror("msgsnd");
	    exit(1);
    }

    printf("Message sent successfully.\n");

    return 0;
}
