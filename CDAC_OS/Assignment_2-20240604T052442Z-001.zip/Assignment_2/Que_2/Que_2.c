#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <stdio.h>
int main()
{
	int p1[2];
	char buff[512];
	char buff1[100];

	printf("enter data you Want read \n");
	fgets(buff1, sizeof(buff1), stdin);

	if (pipe(p1) == -1)
	{
		perror(":");
		return 0;
	}

	int pid = fork();

	if (pid == -1)
	{
		perror(":");
		return 0;
	}

	if (pid == 0)
	{

		if (read(p1[0], &buff, 512) == -1)
		{
			return 0;
		}

		printf("received: %s\n", buff);

		if (write(p1[1], &buff, strlen(buff) + 1) == -1)
		{
			return 0;
		}

		printf("geting data is %s\n", buff);
	}
	else
	{

		if (write(p1[1], &buff1, strlen(buff1) + 1) == -1)
		{
			return 0;
		}

		printf("parent data %s\n", buff1);

		if (read(p1[0], &buff, 512) == -1)
		{
			return 0;
		}

		printf("resulted data is %s \n", buff);
	}
}
